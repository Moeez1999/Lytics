class Constants {
  static int index = 0;
  static bool isSearch = false;
  static String? token;
  bool status = false;
  bool status2 = false;
  bool status3 = false;
  bool status4 = false;
  static var subscription;
}
