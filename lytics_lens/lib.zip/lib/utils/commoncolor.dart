import 'package:flutter/material.dart';

class CommonColor {
  static final Color orangeColor = Color(0xff22B161);
  static final Color sidebarColor = Color(0xffFE9960);
}
