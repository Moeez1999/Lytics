class HorizontalScrollBar {
  final bool isAlwaysShown;

  HorizontalScrollBar({this.isAlwaysShown = false});
}