// import 'package:charts_flutter/flutter.dart' as charts;
// import 'package:flutter/cupertino.dart';
// class GraphData{
//   final String category;
//   final int value;
//   final charts.Color barColor;
//
//   GraphData(this.category,this.value,this.barColor);
// // }