class Channel {
  final int? id;
  final String? name;

  Channel({
    this.id,
    this.name,
  });
}