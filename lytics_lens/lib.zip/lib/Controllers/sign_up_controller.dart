
import 'package:get/get.dart';


class SignUpController extends GetxController{





}